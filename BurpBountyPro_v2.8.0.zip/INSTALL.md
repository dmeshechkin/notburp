# Installation Guide for Burp Bounty Pro

Thank you for choosing Burp Bounty Pro! Follow the steps below to install and start using the extension with Burp Suite.

## Prerequisites

Before installing Burp Bounty Pro, ensure you have the following:

- Burp Suite Professional installed on your system.
- Java Runtime Environment (JRE) version 14 or above.

## Installation Steps

1. **Download the Extension:**
   - Obtain the latest version of Burp Bounty Pro from the official website or your purchase confirmation email.

2. **Launch Burp Suite:**
   - Open Burp Suite Professional.
   - Navigate to the `Extender` tab.

3. **Add the Extension:**
   - In the `Extender` tab, click on the `Extensions` sub-tab.
   - Click on the `Add` button.

4. **Configure the Extension:**
   - In the dialog that appears, select `Java` as the extension type.
   - Click on the `Select file...` button and choose the `BurpBountyPro.jar` file you downloaded.
   - Click `Next` to proceed with the installation.

5. **Verify Installation:**
   - Ensure that the extension is listed in the `Extensions` list and the checkbox next to its name is ticked.
   - Check the Burp Suite Dashboard for any messages from Burp Bounty Pro to confirm it's running.

6. **Start Using Burp Bounty Pro:**
   - Access the newly added `Burp Bounty Pro` tab in the Burp Suite user interface.
   - Begin configuring your profiles and start your security testing.

## Post-Installation

After installing Burp Bounty Pro, you may want to:

- **Review Default Profiles:**
  - Familiarize yourself with the default profiles provided and adjust them to fit your testing needs.

- **Update the Extension:**
  - Check for updates regularly to ensure you have the latest features and fixes.

- **Consult the Documentation:**
  - For detailed usage instructions, visit the documentation page at https://burpbounty.bountysecurity.ai/burp-bounty/.

## Need Help?

If you encounter any issues during the installation or have questions about using Burp Bounty Pro, please contact our support team at hello@bountysecurity.net.

Thank you for using Burp Bounty Pro, and happy hunting!
