CHANGELOG: Burp Bounty Pro Version [2.8.0]
------------------------------------------

### Added
- New profiles for enhanced scanning capabilities:
  - **GraphQL Batching:** Detects potential batching attack vulnerabilities in GraphQL APIs.
  - **GraphQL Alias Overloading:** Identifies issues with excessive use of aliases in GraphQL queries.
  - **GraphQL Circular Queries:** Unveils vulnerabilities related to circular or recursive queries in GraphQL.
  - **GraphQL Directives Overloading:** Tests for overuse and mishandling of directives in GraphQL.
  - **GraphQL Field Duplication:** Checks for unnecessary duplication of fields in GraphQL queries.

### Improved
- Aesthetic and usability enhancements across the interface for a more intuitive user experience.
- Incorporated a new feature allowing users to replace strings or regular expressions in URLs before they are sent to the scanner.

### Optimized
- Existing profiles have been refined to improve detection accuracy and reduce false positives.

